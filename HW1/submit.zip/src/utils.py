# utils.py
def read_instructions(input_file):
    # 从文件读取指令集并返回指令列表
    pass
